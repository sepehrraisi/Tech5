# teamu.ir
### setup
```
python -m venv venv
venv\Scripts\Activate
python manage.py collectstatic
python manage.py runserver
```

### superuser
```
username: admin
password: admin123
```
